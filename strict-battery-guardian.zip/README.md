# Strict Battery Guardian (સ્ટ્રિક્ટ બેટરી ગાર્ડિયન)
### Samsung Galaxy A50s (One UI) માટે સ્માર્ટ બેટરી ગાર્ડિયન એપ્લિકેશન

---

## 📱 પરિચય (Overview)

**Strict Battery Guardian** એ ખાસ કરીને **Samsung Galaxy A50s** (SM-A507F / One UI) સ્માર્ટફોન માટે તૈયાર કરાયેલ શક્તિશાળી, સ્વચ્છ અને ૧૦૦% ગુજરાતી ઇન્ટરફેસ ધરાવતી આધુનિક એન્ડ્રોઇડ એપ્લિકેશન છે. 

આ એપ ૧૫W એડેપ્ટિવ ફાસ્ટ ચાર્જિંગ, ૪૦૦૦ mAh Li-Po બેટરી અને ૬.૪ ઇંચ FHD+ Super AMOLED ડિસ્પ્લેની વિશેષતાઓને ધ્યાનમાં રાખીને બનાવવામાં આવી છે.

---

## ⚡ મુખ્ય વિશેષતાઓ (Key Features)

### ૧. લાઈવ બેટરી મોનિટરિંગ (Live Battery Percentage & Information)
- રીઅલ-ટાઇમ બેટરી ટકાવારી અને ડાયનેમિક કલર આર્ક ગેજ.
- ચાર્જિંગ સ્થિતિ (૧૫W AC ફાસ્ટ ચાર્જર, USB, વાયરલેસ, બેટરી પાવર).
- બેટરી તાપમાન (°C) - તાપમાન ૩૮°C કરતાં વધે ત્યારે ચેતવણી જેથી ફોન ગરમ ન થાય.
- વોલ્ટેજ (V), બેટરી હેલ્થ (Good, Overheat, Dead, Cold) અને ટેકનોલોજી (Li-Po).
- અંદાજિત બાકી રહેલી ક્ષમતા (~mAh / ૪૦૦૦ mAh).

### ૨. ચાર્જિંગ નિયંત્રણ મોડ (Charging Restriction Mode)
- ચાર્જર કનેક્ટ થતાં જ આપમેળે એલર્ટ અને મોનિટરિંગ સક્રિય.
- સેમસંગ વન UI ની **"Protect Battery"** નીતિ અનુસાર **૮૫% લિમિટ એલર્ટ**: બેટરી ૮૫% પહોંચતા જ સાઉન્ડ ટોન અને વાઇબ્રેશન એલર્ટ વાગશે જેથી બેટરી વધુ પડતી ચાર્જ ન થાય અને ૧૦૦૦+ સાઇકલ સુધી બેટરીનું આયુષ્ય ઉત્તમ રહે.
- **સુપર એમોલેડ નાઇટ ચાર્જિંગ સ્ક્રીન (Pure Black #000000)**: રાત્રે ચાર્જિંગ વખતે ૦ mW પિક્સેલ પાવર વપરાશ, જેથી ડિસ્પ્લે ગરમ ન થાય અને સ્ક્રીન બર્ન-ઇનથી બચે.

### ૩. ૨૦% બેટરી એલર્ટ અને પાવર સેવિંગ ગાઇડ (20% Low Battery Warning)
- બેટરી ૨૦% પર પહોંચતા જ ઉચ્ચ-પ્રાથમિકતા (High Priority) સિસ્ટમ નોટિફિકેશન અને વાઇબ્રેશન.
- ૧-ટેપ શોર્ટકટ બટન: સેમસંગના બિલ્ટ-ઇન **Power Saving Mode** સેટિંગ્સ સીધા ખોલો.
- પાવર સેવિંગ મોડમાં CPU સ્પીડ ૭૦% પર લિમિટ થાય છે અને બ્રાઇટનેસ ૧૦% ઘટે છે.

### ૪. મંજૂર એપ્સ સિસ્ટમ (Allowlist Interface: Phone, SMS, WhatsApp)
- કટોકટી કે ઓછી બેટરી વખતે સૌથી અગત્યની ૩ એપ્સ:
  1. **ફોન (Phone / Dialler)**
  2. **સંદેશા (Messages / SMS)**
  3. **વોટ્સએપ (WhatsApp)**
- દરેક એપ માટે સીધું ૧-ક્લિક લોન્ચ બટન અને ઇન્સ્ટોલેશન સ્ટેટસ.
- વપરાશકર્તા પોતાની મનપસંદ અન્ય એપ્સ પણ લિસ્ટમાં ઉમેરી શકે છે.
- સેમસંગ વન UI ના **"Maximum Power Saving Mode (Limit apps and Home screen)"** સાથે સેટઅપ કરવાની સચોટ ગુજરાતી માર્ગદર્શિકા.

### ૫. Android OS સુરક્ષા નિયમો અને વાસ્તવિકતા (Android Sandbox Transparency)
- એપ્લિકેશન Android ની સત્તાવાર સુરક્ષા માર્ગદર્શિકાનું સંપૂર્ણ પાલન કરે છે:
  - થર્ડ-પાર્ટી સામાન્ય એપ્સ અન્ય એપ્સને બળજબરીથી મારી (kill) શકતી નથી કે USB હાર્ડવેર કરંટ કાપી શકતી નથી.
  - સંસ્થાકીય અથવા સંપૂર્ણ કિયોસ્ક લોકડાઉન માટે **Device Owner (ADB)** કમાન્ડનું માર્ગદર્શન પૂરું પાડવામાં આવ્યું છે:
    ```bash
    adb shell dpm set-device-owner com.aistudio.strictbattery.qxpkva/.receiver.DeviceAdminReceiver
    ```

---

## 🛠️ પ્રોજેક્ટ ટેકનિકલ માળખું (Project Structure)

- **ભાષા:** Kotlin (૧૦૦%)
- **UI ફ્રેમવર્ક:** Jetpack Compose (Material Design 3)
- **લઘુત્તમ SDK:** 24 (Android 7.0+)
- **ટાર્ગેટ SDK:** 36 (Android 16 Ready / One UI 2, 3, 4, 5, 6 સુસંગત)
- **આર્કિટેક્ચર:** MVVM (Model-View-ViewModel) + Repository Pattern + Kotlin Coroutines & StateFlow
- **બેકગ્રાઉન્ડ સર્વિસ:** Android Foreground Service with Sticky Lifecycle & High Priority Notifications

---

## 📥 Samsung Galaxy A50s માટે સ્ટેપ-બાય-સ્ટેપ ગુજરાતી ગાઇડ

### ૧. પ્રોજેક્ટ ZIP ડાઉનલોડ અને એક્સ્ટ્રેક્ટ કરવાની રીત
1. આ રિપોઝીટરીમાંથી **`StrictBatteryGuardian.zip`** ફાઈલ ડાઉનલોડ કરો.
2. તમારા કમ્પ્યુટર પર ફાઇલ પર રાઇટ-ક્લિક કરીને **Extract All (અનઝિપ)** કરો.

### ૨. Android Studio માં પ્રોજેક્ટ ઓપન કરવો
1. કમ્પ્યુટર પર **Android Studio** (Ladybug / Koala / Hedgehog અથવા નવીનતમ) ઓપન કરો.
2. સ્વાગત સ્ક્રીન પર **Open** પર ક્લિક કરો.
3. તમે અનઝિપ કરેલું `StrictBatteryGuardian` ફોલ્ડર પસંદ કરીને **OK** દબાવો.
4. Android Studio આપમેળે Gradle Sync શરૂ કરશે. ઇન્ટરનેટ કનેક્શન ચાલુ રાખો જેથી જરૂરી લાઇબ્રેરીઓ ડાઉનલોડ થાય.

### ૩. Debug APK બનાવવાની રીત (Build APK)
1. ટોચના મેનૂબારમાં **Build** મેનૂ પર ક્લિક કરો.
2. **Build Bundle(s) / APK(s)** -> **Build APK(s)** પસંદ કરો.
3. બિલ્ડ પૂર્ણ થતાં જ નીચે જમણી બાજુ **"locate"** લિંક દેખાશે. તેના પર ક્લિક કરવાથી `app-debug.apk` ફાઈલ જોવા મળશે.
   - પાથ: `app/build/outputs/apk/debug/app-debug.apk`
4. વૈકલ્પિક રીતે ટર્મિનલમાં નીચેનો કમાન્ડ ચલાવી શકાય છે:
   ```bash
   gradle assembleDebug
   ```

### ૪. Samsung Galaxy A50s માં USB Debugging ચાલુ કરવું
1. તમારા Samsung Galaxy A50s માં **Settings (સેટિંગ્સ)** ખોલો.
2. છેલ્લે જઈને **About phone (ફોન વિશે)** -> **Software information** પર જાઓ.
3. **Build number** પર સતત ૭ વખત ઝડપથી ટેપ કરો. તમને મેસેજ દેખાશે: *"Developer mode has been enabled"*.
4. પાછા સેટિંગ્સમાં આવી છેલ્લે આવેલ **Developer options** ખોલો.
5. **USB debugging** વિકલ્પ શોધીને તેને **ON (ચાલુ)** કરો.

### ૫. ફોનમાં APK ઇન્સ્ટોલ કરવું
- **રીત ૧ (Android Studio થી સીધું):** USB કેબલ વડે તમારા Galaxy A50s ને કમ્પ્યુટર સાથે જોડો. ફોનની સ્ક્રીન પર *"Allow USB debugging?"* પૂછે ત્યારે **Allow** આપો. Android Studio માં ઉપર લીલા રંગનું **Run (▶)** બટન દબાવો. એપ સીધી તમારા ફોનમાં ઇન્સ્ટોલ થઈ જશે!
- **રીત ૨ (ફાઈલ ટ્રાન્સફર દ્વારા):** `app-debug.apk` ફાઈલને WhatsApp, Google Drive અથવા USB કેબલ દ્વારા તમારા Samsung A50s માં મોકલો. ફોનમાં **My Files (મારી ફાઈલો)** ખોલી `app-debug.apk` પર ટેપ કરીને **Install** દબાવો.

---

## 🔒 જરૂરી પરવાનગીઓ (Permissions)

- `VIBRATE`: ૨૦% ઓછી બેટરી અને ૮૫% ચાર્જિંગ લિમિટ એલર્ટ વખતે વાઇબ્રેશન માટે.
- `RECEIVE_BOOT_COMPLETED`: ફોન રીસ્ટાર્ટ થાય ત્યારે બેટરી ગાર્ડિયન સર્વિસ આપમેળે ચાલુ કરવા માટે.
- `POST_NOTIFICATIONS`: સમયસર સિસ્ટમ નોટિફિકેશન એલર્ટ મોકલવા માટે.
- `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`: સેમસંગ One UI ની ઊંઘ નીતિમાંથી એપને મુક્તિ આપી બેકગ્રાઉન્ડમાં સક્રિય રાખવા માટે.
