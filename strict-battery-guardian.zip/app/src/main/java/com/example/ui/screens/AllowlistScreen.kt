package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.AllowedAppItem
import com.example.data.AllowlistManager
import com.example.ui.BatteryGuardianViewModel
import com.example.ui.UiState
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary

@Composable
fun AllowlistScreen(
    uiState: UiState,
    viewModel: BatteryGuardianViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = stringResource(R.string.allowlist_title),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = stringResource(R.string.allowlist_desc),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Section: Core 3 Allowed Apps (Phone, SMS, WhatsApp)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "પ્રાથમિક મંજૂર એપ્સ (Core Allowed Apps)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        items(uiState.coreAllowedApps, key = { it.id }) { app ->
            AllowedAppCard(
                app = app,
                onLaunch = { viewModel.launchCoreApp(app.id) },
                onRemove = null
            )
        }

        // Section: Custom Allowed Apps
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "વધારાની મંજૂર એપ્સ (${uiState.customAllowedApps.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                OutlinedButton(
                    onClick = { viewModel.showAddAppDialog(true) },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("add_custom_app_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "એપ ઉમેરો", fontSize = 12.sp)
                }
            }
        }

        if (uiState.customAllowedApps.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Text(
                        text = "કોઈ વધારાની એપ ઉમેરેલ નથી. કટોકટીમાં ફક્ત ફોન, સંદેશા અને વોટ્સએપ ચાલુ રાખવાની સલાહ આપવામાં આવે છે.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        } else {
            items(uiState.customAllowedApps, key = { it.packageName }) { app ->
                AllowedAppCard(
                    app = app,
                    onLaunch = { viewModel.launchCustomApp(app.packageName) },
                    onRemove = { viewModel.removeAppFromAllowlist(app.packageName) }
                )
            }
        }

        // Section: Samsung One UI Maximum Power Saving Guide
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Samsung A50s: મહત્તમ પાવર સેવિંગમાં એપ્સ સેટ કરો",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = CyanSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "સેમસંગ વન UI માં આ ૩ એપ્સને લૉકડાઉન મોડમાં રાખવાના પગલાં:\n" +
                                "૧. સેટિંગ્સ -> બેટરી અને ડિવાઇસ કેર (Device Care) -> બેટરી પર જાઓ.\n" +
                                "૨. 'Power Saving' ઓપ્શનમાં 'Limit apps and Home screen' ચાલુ કરો.\n" +
                                "૩. હોમ સ્ક્રીન પર '+' બટન દબાવીને ફોન, સંદેશા અને વોટ્સએપ પસંદ કરો.\n" +
                                "૪. આનાથી અન્ય તમામ એપ્લિકેશન્સ બંધ થશે અને બેટરી ૨૪-૪૮ કલાક વધુ ચાલશે.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.openBatterySaverSettings(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanSecondary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("open_samsung_power_mode_btn")
                    ) {
                        Text("સેમસંગ પાવર સેવિંગ સેટિંગ્સ ખોલો", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Add App Dialog
    if (uiState.showAddAppDialog) {
        AlertDialog(
            onDismissRequest = { viewModel.showAddAppDialog(false) },
            title = {
                Text("માન્ય લિસ્ટમાં નવી એપ ઉમેરો", fontWeight = FontWeight.Bold)
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    items(uiState.allInstalledApps) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = app.label,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = { viewModel.addAppToAllowlist(app.packageName) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                            ) {
                                Text("ઉમેરો", color = Color.Black, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { viewModel.showAddAppDialog(false) }) {
                    Text("રદ કરો")
                }
            }
        )
    }
}

@Composable
fun AllowedAppCard(
    app: AllowedAppItem,
    onLaunch: () -> Unit,
    onRemove: (() -> Unit)?
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("allowed_app_${app.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                val icon = when (app.id) {
                    AllowlistManager.ID_PHONE -> Icons.Default.Call
                    AllowlistManager.ID_SMS -> Icons.Default.Message
                    AllowlistManager.ID_WHATSAPP -> Icons.Default.Chat
                    else -> Icons.Default.Launch
                }
                val iconColor = when (app.id) {
                    AllowlistManager.ID_PHONE -> EmeraldPrimary
                    AllowlistManager.ID_SMS -> CyanSecondary
                    AllowlistManager.ID_WHATSAPP -> Color(0xFF25D366)
                    else -> MaterialTheme.colorScheme.onSurface
                }

                Icon(
                    imageVector = icon,
                    contentDescription = app.nameGujarati,
                    tint = iconColor,
                    modifier = Modifier.size(32.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = app.nameGujarati,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (app.isInstalled) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (app.usageTimeMinutesToday > 0) "આજે સ્ક્રીન સમય: ${app.usageTimeMinutesToday} મિનિટ" else "તૈયાર (ઇન્સ્ટોલ કરેલ)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = Color.Red,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ફોનમાં ઇન્સ્ટોલ નથી",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Red
                            )
                        }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = onLaunch,
                    enabled = app.isInstalled,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    modifier = Modifier.testTag("launch_btn_${app.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Launch,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "ખોલો", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                if (onRemove != null) {
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(onClick = onRemove) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "હટાવો",
                            tint = Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
