package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF10B981)
val EmeraldOnPrimary = Color(0xFF003822)
val EmeraldContainer = Color(0xFF064E3B)
val EmeraldOnContainer = Color(0xFFA7F3D0)

val CyanSecondary = Color(0xFF06B6D4)
val CyanOnSecondary = Color(0xFF00363F)
val CyanContainer = Color(0xFF164E63)
val CyanOnContainer = Color(0xFFA5F3FC)

val AmberWarning = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF78350F)
val CrimsonError = Color(0xFFEF4444)
val CrimsonContainer = Color(0xFF7F1D1D)

val DarkBackground = Color(0xFF070B14)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOutline = Color(0xFF334155)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val PureBlack = Color(0xFF000000)
