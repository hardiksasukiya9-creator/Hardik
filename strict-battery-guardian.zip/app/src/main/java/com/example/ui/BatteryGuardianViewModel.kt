package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AllowedAppItem
import com.example.data.AllowlistManager
import com.example.data.AppItem
import com.example.data.BatteryRepository
import com.example.data.BatteryState
import com.example.data.GuardianSettings
import com.example.service.BatteryGuardianService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val batteryState: BatteryState = BatteryState(),
    val settings: GuardianSettings = GuardianSettings(),
    val coreAllowedApps: List<AllowedAppItem> = emptyList(),
    val customAllowedApps: List<AllowedAppItem> = emptyList(),
    val allInstalledApps: List<AppItem> = emptyList(),
    val isIgnoringBatteryOptimizations: Boolean = false,
    val hasUsageStatsPermission: Boolean = false,
    val isAmoledChargingScreenActive: Boolean = false,
    val showAddAppDialog: Boolean = false,
    val showChargingConnectedDialog: Boolean = false,
    val alertToastMessage: String? = null
)

class BatteryGuardianViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BatteryRepository(application)
    private val allowlistManager = AllowlistManager(application)

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        // Collect Battery State
        viewModelScope.launch {
            repository.batteryState.collectLatest { batteryState ->
                _uiState.update { it.copy(batteryState = batteryState) }
            }
        }

        // Collect Settings
        viewModelScope.launch {
            repository.settings.collectLatest { settings ->
                _uiState.update { it.copy(settings = settings) }
                if (settings.isGuardianServiceEnabled) {
                    BatteryGuardianService.start(getApplication())
                }
            }
        }

        // Collect Alert Events
        viewModelScope.launch {
            repository.alertEvent.collectLatest { event ->
                when (event) {
                    "CHARGING_STARTED" -> {
                        _uiState.update { it.copy(showChargingConnectedDialog = true) }
                    }
                    "LOW_BATTERY_ALERT" -> {
                        _uiState.update { it.copy(alertToastMessage = "બેટરી ૨૦% પર પહોંચી છે! પાવર સેવિંગ મોડ ચાલુ કરો.") }
                    }
                    "CHARGE_LIMIT_ALERT" -> {
                        _uiState.update { it.copy(alertToastMessage = "ચાર્જિંગ લિમિટ પહોંચી ગઈ છે! કૃપા કરીને ચાર્જર અનપ્લગ કરો.") }
                    }
                    "TEST_ALERT" -> {
                        _uiState.update { it.copy(alertToastMessage = "ટેસ્ટ નોટિફિકેશન અને વાઇબ્રેશન સફળતાપૂર્વક મોકલવામાં આવ્યું!") }
                    }
                }
            }
        }

        refreshAppLists()
        checkPermissions()
    }

    fun refreshAppLists() {
        val core = allowlistManager.getCoreAllowedApps()
        val custom = allowlistManager.getCustomAllowedApps()
        val allApps = allowlistManager.getAllInstalledLaunchableApps()
        _uiState.update {
            it.copy(
                coreAllowedApps = core,
                customAllowedApps = custom,
                allInstalledApps = allApps
            )
        }
    }

    fun checkPermissions() {
        val context = getApplication<Application>()
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isIgnoring = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pm?.isIgnoringBatteryOptimizations(context.packageName) ?: false
        } else true

        val hasUsage = allowlistManager.hasUsageStatsPermission()
        _uiState.update {
            it.copy(
                isIgnoringBatteryOptimizations = isIgnoring,
                hasUsageStatsPermission = hasUsage
            )
        }
    }

    fun toggleGuardianService(enabled: Boolean) {
        val newSettings = _uiState.value.settings.copy(isGuardianServiceEnabled = enabled)
        repository.updateSettings(newSettings)
        if (enabled) {
            BatteryGuardianService.start(getApplication())
        } else {
            BatteryGuardianService.stop(getApplication())
        }
    }

    fun setChargingLimit(limit: Int) {
        val newSettings = _uiState.value.settings.copy(chargingLimitThreshold = limit)
        repository.updateSettings(newSettings)
    }

    fun setLowBatteryThreshold(threshold: Int) {
        val newSettings = _uiState.value.settings.copy(lowBatteryThreshold = threshold)
        repository.updateSettings(newSettings)
    }

    fun toggleSoundAlert(enabled: Boolean) {
        val newSettings = _uiState.value.settings.copy(isSoundAlertEnabled = enabled)
        repository.updateSettings(newSettings)
    }

    fun toggleVibration(enabled: Boolean) {
        val newSettings = _uiState.value.settings.copy(isVibrationEnabled = enabled)
        repository.updateSettings(newSettings)
    }

    fun toggleAmoledScreenOnCharge(enabled: Boolean) {
        val newSettings = _uiState.value.settings.copy(isAmoledScreenOnCharge = enabled)
        repository.updateSettings(newSettings)
    }

    fun setAmoledChargingScreenActive(active: Boolean) {
        _uiState.update { it.copy(isAmoledChargingScreenActive = active) }
    }

    fun dismissChargingDialog() {
        _uiState.update { it.copy(showChargingConnectedDialog = false) }
    }

    fun dismissToast() {
        _uiState.update { it.copy(alertToastMessage = null) }
    }

    fun showAddAppDialog(show: Boolean) {
        _uiState.update { it.copy(showAddAppDialog = show) }
    }

    fun addAppToAllowlist(pkg: String) {
        allowlistManager.addCustomAllowedPackage(pkg)
        refreshAppLists()
        showAddAppDialog(false)
    }

    fun removeAppFromAllowlist(pkg: String) {
        allowlistManager.removeCustomAllowedPackage(pkg)
        refreshAppLists()
    }

    fun launchCoreApp(id: String) {
        when (id) {
            AllowlistManager.ID_PHONE -> allowlistManager.launchPhone()
            AllowlistManager.ID_SMS -> allowlistManager.launchSms()
            AllowlistManager.ID_WHATSAPP -> allowlistManager.launchWhatsApp()
        }
    }

    fun launchCustomApp(packageName: String) {
        allowlistManager.launchAppByPackage(packageName)
    }

    fun triggerTestAlert() {
        repository.triggerTestAlert()
    }

    // System Intents
    fun openBatterySaverSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            openGeneralBatterySettings(context)
        }
    }

    fun openGeneralBatterySettings(context: Context) {
        try {
            val intent = Intent(Intent.ACTION_POWER_USAGE_SUMMARY).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }

    fun requestIgnoreBatteryOptimization(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (_: Exception) {
                val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        }
    }

    fun openUsageAccessSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository.unregisterBatteryReceiver()
    }
}
