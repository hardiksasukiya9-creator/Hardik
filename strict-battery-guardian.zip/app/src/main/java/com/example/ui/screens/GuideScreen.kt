package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.BatteryGuardianViewModel
import com.example.ui.UiState
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary

@Composable
fun GuideScreen(
    uiState: UiState,
    viewModel: BatteryGuardianViewModel,
    onRequestNotificationPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = stringResource(R.string.guide_title),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Text(
            text = stringResource(R.string.guide_intro),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Card 1: Permissions Manager
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "સિસ્ટમ પરવાનગીઓ (System Permissions)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Notification Permission
                PermissionRow(
                    title = "નોટિફિકેશન એલર્ટ્સ",
                    desc = "૨૦% બેટરી અને ૮૫% ચાર્જિંગ ચેતવણી માટે જરૂરી",
                    icon = Icons.Default.Notifications,
                    isGranted = true, // Normal or granted
                    actionLabel = "ચકાસો",
                    onAction = onRequestNotificationPermission
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Battery Optimization Exemption
                PermissionRow(
                    title = "બેટરી ઑપ્ટિમાઇઝેશન મુક્તિ",
                    desc = "સેમસંગ વન UI બેકગ્રાઉન્ડ સર્વિસને આપમેળે ઊંઘમાં ન નાખે તે માટે",
                    icon = Icons.Default.BatteryAlert,
                    isGranted = uiState.isIgnoringBatteryOptimizations,
                    actionLabel = if (uiState.isIgnoringBatteryOptimizations) "મંજૂર" else "મુક્તિ આપો",
                    onAction = { viewModel.requestIgnoreBatteryOptimization(context) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Usage Access
                PermissionRow(
                    title = "વપરાશ એક્સેસ (Usage Stats)",
                    desc = "ફોન, SMS અને WhatsApp નો સ્ક્રીન સમય ગણવા માટે",
                    icon = Icons.Default.QueryStats,
                    isGranted = uiState.hasUsageStatsPermission,
                    actionLabel = if (uiState.hasUsageStatsPermission) "મંજૂર" else "પરવાનગી આપો",
                    onAction = { viewModel.openUsageAccessSettings(context) }
                )
            }
        }

        // Card 2: Honest Android OS Security Boundaries
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = CyanSecondary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Android સુરક્ષા નીતિ અને વાસ્તવિકતા",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyanSecondary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "૧. એપ્સ બ્લોકિંગ:\n" +
                            "Android OS સેન્ડબોક્સ સુરક્ષા મુજબ કોઈ સામાન્ય થર્ડ-પાર્ટી એપ અન્ય એપ્સને બળજબરીપૂર્વક મારી (kill) શકતી નથી કે તેમના ઇન્ટરનેટને બ્લોક કરી શકતી નથી.\n\n" +
                            "૨. પાવર સેવિંગ સ્વિચ:\n" +
                            "Android 9/10/11 સુરક્ષા નિયમો મુજબ ફક્ત સિસ્ટમ સેટિંગ્સ અથવા યૂઝર પોતે જ પાવર સેવિંગ મોડ ઓન/ઓફ કરી શકે છે. તેથી અમે સીધા ૧-ક્લિક બટન દ્વારા સેમસંગના મૂળ પાવર સેવિંગ સેટિંગ્સ પર મોકલીએ છીએ.\n\n" +
                            "૩. હાર્ડવેર ચાર્જિંગ કટ:\n" +
                            "USB-C માંથી ચાર્જિંગ રોકવું હાર્ડવેર કંટ્રોલર પર આધારિત છે. સેમસંગ ગેલેક્સી A50s માં આ માટે 'Protect Battery (૮૫%)' સેટિંગ આપેલું છે.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 20.sp
                )
            }
        }

        // Card 3: Device Owner / Kiosk Mode Guide
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = AmberWarning)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Device Owner / Kiosk Mode સમજૂતી",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = AmberWarning
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "જો તમારે ફોન પર સંપૂર્ણ નિયંત્રણ (કિયોસ્ક લોકડાઉન) જોઈતું હોય જેથી યૂઝર માત્ર ફોન, મેસેજ અને વોટ્સએપ સિવાય કશું જ ન ખોલી શકે, તો ADB દ્વારા Device Owner બનાવી શકાય છે:\n\n" +
                            "કમાન્ડ:\n" +
                            "adb shell dpm set-device-owner com.aistudio.strictbattery.qxpkva/.receiver.DeviceAdminReceiver\n\n" +
                            "નોંધ: સામાન્ય ઉપયોગ માટે સેમસંગ One UI નું 'Ultra / Maximum Power Saving' સૌથી સલામત અને સરળ છે.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 19.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Card 4: Samsung Galaxy A50s APK Installation Guide
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Smartphone, contentDescription = null, tint = EmeraldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Samsung Galaxy A50s પર ઇન્સ્ટોલેશન ગાઇડ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "પગલું ૧: StrictBatteryGuardian.zip ડાઉનલોડ કરો અને તમારા કમ્પ્યુટર પર Extract (અનઝિપ) કરો.\n\n" +
                            "પગલું ૨: Android Studio ખોલો અને 'Open' પસંદ કરીને પ્રોજેક્ટ ફોલ્ડર સિલેક્ટ કરો.\n\n" +
                            "પગલું ૩: ગ્રેડલ સિંક પૂર્ણ થયા બાદ ટોચના મેનૂમાંથી Build -> Build Bundle(s) / APK(s) -> Build APK(s) પર ક્લિક કરો.\n\n" +
                            "પગલું ૪: તમારા Samsung Galaxy A50s માં સેટિંગ્સ -> About phone -> Software information માં જઈ 'Build number' પર ૭ વાર ટેપ કરીને 'Developer Options' ચાલુ કરો અને 'USB debugging' ઓન કરો.\n\n" +
                            "પગલું ૫: USB કેબલ વડે ફોન જોડીને Android Studio માંથી સીધું Run દબાવો અથવા 'app-debug.apk' ફાઈલ ફોનમાં મોકલીને 'Install' પર ટેપ કરો.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 21.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun PermissionRow(
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isGranted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isGranted) EmeraldPrimary else AmberWarning,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }
        }

        Button(
            onClick = onAction,
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isGranted) Color(0xFF1E293B) else EmeraldPrimary
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            if (isGranted) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            Text(
                text = actionLabel,
                color = if (isGranted) EmeraldPrimary else Color.Black,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
