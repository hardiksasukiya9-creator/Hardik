package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BatteryState
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.PureBlack
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AmoledChargingOverlay(
    batteryState: BatteryState,
    targetLimit: Int,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentTime by remember { mutableStateOf(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            delay(1000)
        }
    }

    val isLimitReached = batteryState.percentage >= targetLimit

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(24.dp)
            .testTag("amoled_charging_overlay")
    ) {
        // Exit button at top right
        IconButton(
            onClick = onDismiss,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(48.dp)
                .background(Color(0xFF1E293B).copy(alpha = 0.6f), CircleShape)
                .testTag("exit_amoled_button")
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "બંધ કરો",
                tint = Color.White
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "AMOLED નાઇટ ચાર્જિંગ મોડ",
                fontSize = 14.sp,
                color = Color(0xFF64748B),
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = currentTime,
                fontSize = 64.sp,
                fontWeight = FontWeight.Light,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(32.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = "ચાર્જિંગ",
                    tint = if (isLimitReached) AmberWarning else CyanSecondary,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${batteryState.percentage}%",
                    fontSize = 52.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isLimitReached) AmberWarning else EmeraldPrimary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (batteryState.isCharging) {
                    "૧૫W ફાસ્ટ ચાર્જિંગ સક્રિય • ${batteryState.plugType.getGujaratiLabel()}"
                } else {
                    "ચાર્જર ડિસ્કનેક્ટ થયેલ છે"
                },
                fontSize = 14.sp,
                color = Color(0xFF94A3B8)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Thermostat,
                    contentDescription = "તાપમાન",
                    tint = Color(0xFF64748B),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "બેટરી તાપમાન: ${batteryState.temperatureCelsius}°C",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.height(40.dp))

            if (isLimitReached) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF451A03)),
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "લક્ષ્ય $targetLimit% પૂર્ણ થયું!",
                            fontWeight = FontWeight.Bold,
                            color = AmberWarning,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "સેમસંગ A50s ની બેટરી સાચવવા માટે ચાર્જર હટાવી લો.",
                            color = Color(0xFFFDE68A),
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                Text(
                    text = "લક્ષ્ય લિમિટ: $targetLimit% (પહોંચતા જ એલર્ટ વાગશે)",
                    fontSize = 12.sp,
                    color = Color(0xFF475569)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("exit_overlay_button")
            ) {
                Text("સામાન્ય સ્ક્રીન પર પાછા જાઓ", color = Color.White)
            }
        }
    }
}
