package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.EnergySavingsLeaf
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.BatteryGuardianViewModel
import com.example.ui.UiState
import com.example.ui.components.BatteryGauge
import com.example.ui.components.MetricCard
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldPrimary

@Composable
fun HomeScreen(
    uiState: UiState,
    viewModel: BatteryGuardianViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val battery = uiState.batteryState

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Device Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = stringResource(R.string.app_name_gujarati),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Samsung Galaxy A50s • One UI",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Power Saver Status Pill
            Box(
                modifier = Modifier
                    .background(
                        color = if (battery.isPowerSaveMode) EmeraldPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(
                                color = if (battery.isPowerSaveMode) EmeraldPrimary else Color.Gray,
                                shape = CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (battery.isPowerSaveMode) "પાવર સેવિંગ ON" else "સામાન્ય મોડ",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (battery.isPowerSaveMode) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Circular Gauge
        BatteryGauge(
            batteryState = battery,
            size = 220.dp,
            modifier = Modifier.testTag("home_battery_gauge")
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Low Battery Banner (<= 20%)
        if (battery.percentage <= uiState.settings.lowBatteryThreshold && !battery.isCharging) {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("low_battery_warning_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = CrimsonError.copy(alpha = 0.15f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.BatteryAlert,
                            contentDescription = "ચેતવણી",
                            tint = CrimsonError,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.low_battery_warning_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = CrimsonError
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "બેટરી ૨૦% પર પહોંચી ગઈ છે. સેમસંગ વન UI માં પાવર સેવિંગ મોડ ચાલુ કરવાથી CPU ઝડપ ૭૦% પર સીમિત થશે, બ્રાઇટનેસ ૧૦% ઘટશે અને બેકગ્રાઉન્ડ ડેટા અટકીને બેટરી બચશે.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.openBatterySaverSettings(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonError),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("enable_power_saver_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.BatterySaver, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.action_enable_battery_saver),
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Metrics Grid (2x2)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = stringResource(R.string.temperature),
                value = "${battery.temperatureCelsius} °C",
                subtitle = if (battery.temperatureCelsius > 38f) "ગરમ (સાવચેત રહો)" else "સામાન્ય (Safe)",
                icon = Icons.Default.Thermostat,
                iconTint = if (battery.temperatureCelsius > 38f) CrimsonError else CyanSecondary,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = stringResource(R.string.voltage),
                value = String.format("%.2f V", battery.voltageVolts),
                subtitle = battery.technology,
                icon = Icons.Default.Bolt,
                iconTint = AmberWarning,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricCard(
                title = stringResource(R.string.health),
                value = battery.health.getGujaratiLabel(),
                subtitle = "૪૦૦૦ mAh Li-Po",
                icon = Icons.Default.VerifiedUser,
                iconTint = EmeraldPrimary,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "ચાર્જિંગ સ્પીડ",
                value = if (battery.isCharging) "${battery.chargingSpeedWatts}W" else "0W",
                subtitle = battery.plugType.getGujaratiLabel(),
                icon = Icons.Default.Power,
                iconTint = if (battery.isCharging) CyanSecondary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Actions
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "ઝડપી ક્રિયાઓ (Quick Actions)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.openBatterySaverSettings(context) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("action_battery_saver_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.EnergySavingsLeaf, contentDescription = null, tint = EmeraldPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("પાવર સેવિંગ", fontSize = 11.sp)
                        }
                    }

                    OutlinedButton(
                        onClick = { viewModel.openGeneralBatterySettings(context) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("action_samsung_care_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = CyanSecondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("સેમસંગ સેટિંગ્સ", fontSize = 11.sp)
                        }
                    }

                    OutlinedButton(
                        onClick = { viewModel.setAmoledChargingScreenActive(true) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("action_amoled_screen_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("AMOLED મોડ", fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { viewModel.triggerTestAlert() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("test_alert_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = AmberWarning,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ટેસ્ટ નોટિફિકેશન અને સાઉન્ડ ચકાસો",
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Samsung Galaxy A50s Hardware Profile Info Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "સેમસંગ ગેલેક્સી A50s હાર્ડવેર સ્પેક્સ",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• બેટરી: ૪૦૦૦ mAh Lithium-Polymer (Li-Po)\n• ચાર્જિંગ: ૧૫W Adaptive Fast Charging (USB-C)\n• પ્રોસેસર: Exynos 9611 (10nm FinFET) Octa-Core\n• ડિસ્પ્લે: ૬.૪ ઇંચ FHD+ Super AMOLED (Dark Theme માં ૦ mW પિક્સેલ બચત)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
