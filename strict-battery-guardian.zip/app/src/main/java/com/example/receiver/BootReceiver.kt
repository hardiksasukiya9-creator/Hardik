package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.service.BatteryGuardianService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val prefs = context.getSharedPreferences("strict_battery_prefs", Context.MODE_PRIVATE)
            val isEnabled = prefs.getBoolean("service_enabled", true)
            if (isEnabled) {
                BatteryGuardianService.start(context)
            }
        }
    }
}
