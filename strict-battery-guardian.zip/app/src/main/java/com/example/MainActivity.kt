package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Power
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.BatteryGuardianViewModel
import com.example.ui.components.AmoledChargingOverlay
import com.example.ui.screens.AllowlistScreen
import com.example.ui.screens.ChargingScreen
import com.example.ui.screens.GuideScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: BatteryGuardianViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainApp(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkPermissions()
        viewModel.refreshAppLists()
    }
}

enum class NavigationTab(val titleRes: Int) {
    HOME(R.string.nav_home),
    CHARGING(R.string.nav_charging),
    ALLOWLIST(R.string.nav_allowlist),
    GUIDE(R.string.nav_guide)
}

@Composable
fun MainApp(viewModel: BatteryGuardianViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }

    // Notification Permission Launcher (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "નોટિફિકેશન મંજૂરી સફળ થઈ!", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(uiState.alertToastMessage) {
        uiState.alertToastMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissToast()
        }
    }

    // BackHandler for AMOLED screen
    BackHandler(enabled = uiState.isAmoledChargingScreenActive) {
        viewModel.setAmoledChargingScreenActive(false)
    }

    // BackHandler for non-home tab
    BackHandler(enabled = !uiState.isAmoledChargingScreenActive && selectedTab != 0) {
        selectedTab = 0
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSurface,
                    tonalElevation = 8.dp
                ) {
                    val tabs = NavigationTab.entries
                    tabs.forEachIndexed { index, tab ->
                        val isSelected = selectedTab == index
                        val (selectedIcon, unselectedIcon) = when (tab) {
                            NavigationTab.HOME -> Icons.Filled.Home to Icons.Outlined.Home
                            NavigationTab.CHARGING -> Icons.Filled.Power to Icons.Outlined.Power
                            NavigationTab.ALLOWLIST -> Icons.Filled.Apps to Icons.Outlined.Apps
                            NavigationTab.GUIDE -> Icons.Filled.Info to Icons.Outlined.Info
                        }

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { selectedTab = index },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) selectedIcon else unselectedIcon,
                                    contentDescription = stringResource(tab.titleRes)
                                )
                            },
                            label = {
                                Text(
                                    text = stringResource(tab.titleRes),
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                selectedTextColor = EmeraldPrimary,
                                indicatorColor = EmeraldPrimary,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    0 -> HomeScreen(uiState = uiState, viewModel = viewModel)
                    1 -> ChargingScreen(uiState = uiState, viewModel = viewModel)
                    2 -> AllowlistScreen(uiState = uiState, viewModel = viewModel)
                    3 -> GuideScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onRequestNotificationPermission = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                Toast.makeText(context, "આ એન્ડ્રોઇડ વર્ઝનમાં પરવાનગી પહેલેથી જ મંજૂર છે.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
        }

        // AMOLED Night Charging Fullscreen Overlay
        AnimatedVisibility(visible = uiState.isAmoledChargingScreenActive) {
            AmoledChargingOverlay(
                batteryState = uiState.batteryState,
                targetLimit = uiState.settings.chargingLimitThreshold,
                onDismiss = { viewModel.setAmoledChargingScreenActive(false) }
            )
        }

        // Charging Connected Dialog (Prompt user when charger is plugged in)
        if (uiState.showChargingConnectedDialog) {
            AlertDialog(
                onDismissRequest = { viewModel.dismissChargingDialog() },
                title = {
                    Row {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = CyanSecondary)
                        Text(
                            text = " ચાર્જર કનેક્ટ થયું!",
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                text = {
                    Text(
                        text = "ચાર્જિંગ નિયંત્રણ મોડ સક્રિય છે. બેટરી ${uiState.settings.chargingLimitThreshold}% પર પહોંચશે ત્યારે એલર્ટ વાગશે.\n\nશું તમે બેટરી બચાવવા માટે AMOLED નાઇટ સ્ક્રીન શરૂ કરવા માંગો છો?",
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.dismissChargingDialog()
                            viewModel.setAmoledChargingScreenActive(true)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("AMOLED સ્ક્રીન ઓન કરો", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.dismissChargingDialog() }) {
                        Text("બંધ રાખો")
                    }
                }
            )
        }
    }
}
