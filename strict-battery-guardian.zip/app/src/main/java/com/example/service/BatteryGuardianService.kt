package com.example.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.data.BatteryRepository
import com.example.data.PlugType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class BatteryGuardianService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var repository: BatteryRepository

    override fun onCreate() {
        super.onCreate()
        repository = BatteryRepository(applicationContext)

        val initialNotif = NotificationHelper.buildServiceNotification(
            this,
            50,
            false,
            "બેટરી પાવર"
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceCompat.startForeground(
                    this,
                    NotificationHelper.NOTIFICATION_ID_SERVICE,
                    initialNotif,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NotificationHelper.NOTIFICATION_ID_SERVICE, initialNotif)
            }
        } catch (_: Throwable) {
            // Guard against ForegroundServiceStartNotAllowedException on newer Android versions
        }

        serviceScope.launch {
            repository.batteryState.collectLatest { state ->
                try {
                    val sourceLabel = state.plugType.getGujaratiLabel()
                    val notif = NotificationHelper.buildServiceNotification(
                        this@BatteryGuardianService,
                        state.percentage,
                        state.isCharging,
                        sourceLabel
                    )
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? android.app.NotificationManager
                    nm?.notify(NotificationHelper.NOTIFICATION_ID_SERVICE, notif)
                } catch (_: Throwable) {
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        try {
            repository.unregisterBatteryReceiver()
        } catch (_: Throwable) {
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, BatteryGuardianService::class.java)
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Throwable) {
                // Catches ForegroundServiceStartNotAllowedException on Android 12+
                try {
                    context.startService(intent)
                } catch (_: Throwable) {
                }
            }
        }

        fun stop(context: Context) {
            try {
                val intent = Intent(context, BatteryGuardianService::class.java)
                context.stopService(intent)
            } catch (_: Throwable) {
            }
        }
    }
}
