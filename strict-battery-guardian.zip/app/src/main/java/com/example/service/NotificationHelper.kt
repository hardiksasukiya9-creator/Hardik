package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.BatteryGuardianApplication
import com.example.MainActivity
import com.example.R

object NotificationHelper {

    private const val NOTIFICATION_ID_LOW_BATTERY = 2001
    private const val NOTIFICATION_ID_CHARGING_LIMIT = 2002
    const val NOTIFICATION_ID_SERVICE = 1001

    fun buildServiceNotification(
        context: Context,
        percentage: Int,
        isCharging: Boolean,
        chargingSource: String
    ): Notification {
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusText = if (isCharging) {
            "ચાર્જ થઈ રહી છે ($chargingSource) • $percentage%"
        } else {
            "બેટરી સ્થિતિ: $percentage% • સુરક્ષા સક્રિય"
        }

        return NotificationCompat.Builder(context, BatteryGuardianApplication.CHANNEL_SERVICE_ID)
            .setContentTitle("Strict Battery Guardian (A50s)")
            .setContentText(statusText)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    fun showLowBatteryNotification(context: Context, percentage: Int) {
        try {
            val powerSaverIntent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            val powerSaverPendingIntent = PendingIntent.getActivity(
                context,
                1,
                powerSaverIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val openAppIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val appPendingIntent = PendingIntent.getActivity(
                context,
                2,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val builder = NotificationCompat.Builder(context, BatteryGuardianApplication.CHANNEL_ALERTS_ID)
                .setContentTitle(context.getString(R.string.notif_low_battery_title))
                .setContentText("બેટરી $percentage% છે! સેમસંગ પાવર સેવિંગ મોડ તરત જ ચાલુ કરો.")
                .setSmallIcon(R.drawable.ic_notification)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setSound(soundUri)
                .setVibrate(longArrayOf(0, 500, 200, 500, 200, 500))
                .setContentIntent(appPendingIntent)
                .addAction(
                    android.R.drawable.ic_lock_power_off,
                    context.getString(R.string.action_enable_battery_saver),
                    powerSaverPendingIntent
                )

            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_LOW_BATTERY, builder.build())
        } catch (_: Throwable) {
            // Guard against SecurityException or RemoteServiceException
        }
    }

    fun showChargingLimitNotification(context: Context, percentage: Int, limit: Int) {
        try {
            val openAppIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val appPendingIntent = PendingIntent.getActivity(
                context,
                3,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)

            val builder = NotificationCompat.Builder(context, BatteryGuardianApplication.CHANNEL_ALERTS_ID)
                .setContentTitle("ચાર્જિંગ લિમિટ એલર્ટ: $percentage%!")
                .setContentText("બેટરી $limit% લક્ષ્ય પર પહોંચી ગઈ છે. બેટરી આયુષ્ય જાળવવા ચાર્જર અનપ્લગ કરો.")
                .setSmallIcon(R.drawable.ic_notification)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setSound(soundUri)
                .setVibrate(longArrayOf(0, 400, 150, 400))
                .setContentIntent(appPendingIntent)

            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_CHARGING_LIMIT, builder.build())
        } catch (_: Throwable) {
            // Guard against SecurityException or RemoteServiceException
        }
    }

    fun triggerVibration(context: Context) {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 300, 150, 300),
                        -1
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(500)
            }
        } catch (_: Throwable) {
        }
    }
}
