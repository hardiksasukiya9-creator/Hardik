package com.example.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import com.example.service.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class BatteryRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("strict_battery_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.Default)

    private val _batteryState = MutableStateFlow(BatteryState())
    val batteryState: StateFlow<BatteryState> = _batteryState.asStateFlow()

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<GuardianSettings> = _settings.asStateFlow()

    // Event bus for alerts to trigger UI events
    private val _alertEvent = MutableSharedFlow<String>()
    val alertEvent: SharedFlow<String> = _alertEvent.asSharedFlow()

    private var lowBatteryAlertFiredForCycle = false
    private var chargeLimitAlertFiredForCycle = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            intent?.let { handleBatteryIntent(it) }
        }
    }

    private var isReceiverRegistered = false

    init {
        registerBatteryReceiver()
    }

    fun registerBatteryReceiver() {
        if (!isReceiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
                addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            }
            val initialStickyIntent = context.registerReceiver(batteryReceiver, filter)
            isReceiverRegistered = true
            initialStickyIntent?.let { handleBatteryIntent(it) }
        }
    }

    fun unregisterBatteryReceiver() {
        if (isReceiverRegistered) {
            try {
                context.unregisterReceiver(batteryReceiver)
            } catch (_: Exception) {
            }
            isReceiverRegistered = false
        }
    }

    private fun handleBatteryIntent(intent: Intent) {
        val action = intent.action ?: return
        val currentSettings = _settings.value

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isPowerSaveMode = powerManager?.isPowerSaveMode ?: false

        if (action == Intent.ACTION_POWER_CONNECTED) {
            chargeLimitAlertFiredForCycle = false
            scope.launch {
                _alertEvent.emit("CHARGING_STARTED")
            }
        }

        if (action == Intent.ACTION_POWER_DISCONNECTED) {
            chargeLimitAlertFiredForCycle = false
        }

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val percentage = if (level >= 0 && scale > 0) (level * 100) / scale else 50

        val rawStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val status = when (rawStatus) {
            BatteryManager.BATTERY_STATUS_CHARGING -> BatteryStatus.CHARGING
            BatteryManager.BATTERY_STATUS_DISCHARGING -> BatteryStatus.DISCHARGING
            BatteryManager.BATTERY_STATUS_FULL -> BatteryStatus.FULL
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> BatteryStatus.NOT_CHARGING
            else -> BatteryStatus.UNKNOWN
        }

        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val plugType = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> PlugType.AC
            BatteryManager.BATTERY_PLUGGED_USB -> PlugType.USB
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> PlugType.WIRELESS
            else -> PlugType.BATTERY
        }
        val isCharging = status == BatteryStatus.CHARGING || plugged != 0

        val rawHealth = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val health = when (rawHealth) {
            BatteryManager.BATTERY_HEALTH_GOOD -> BatteryHealth.GOOD
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> BatteryHealth.OVERHEAT
            BatteryManager.BATTERY_HEALTH_DEAD -> BatteryHealth.DEAD
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> BatteryHealth.OVER_VOLTAGE
            BatteryManager.BATTERY_HEALTH_COLD -> BatteryHealth.COLD
            else -> BatteryHealth.UNKNOWN
        }

        val tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 300)
        val temperatureCelsius = tempRaw / 10.0f

        val voltageRaw = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 3850)
        val voltageVolts = if (voltageRaw > 100) voltageRaw / 1000.0f else voltageRaw.toFloat()

        val technology = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-ion"

        // Samsung Galaxy A50s design capacity is 4000 mAh
        val designCapacityMah = 4000
        val estimatedCapacityMah = (percentage / 100.0f * designCapacityMah).toInt()

        val chargingSpeedWatts = when {
            !isCharging -> 0.0f
            plugType == PlugType.AC -> 15.0f // Samsung Galaxy A50s 15W Adaptive Fast Charging
            plugType == PlugType.USB -> 5.0f
            else -> 10.0f
        }

        val newState = BatteryState(
            percentage = percentage,
            isCharging = isCharging,
            status = status,
            plugType = plugType,
            health = health,
            temperatureCelsius = temperatureCelsius,
            voltageVolts = voltageVolts,
            technology = technology,
            isPowerSaveMode = isPowerSaveMode,
            estimatedCapacityMah = estimatedCapacityMah,
            chargingSpeedWatts = chargingSpeedWatts,
            timestampMillis = System.currentTimeMillis()
        )

        _batteryState.value = newState

        // Check Low Battery Alert (<= 20% by default)
        if (!isCharging && percentage <= currentSettings.lowBatteryThreshold) {
            if (!lowBatteryAlertFiredForCycle) {
                lowBatteryAlertFiredForCycle = true
                if (currentSettings.isSoundAlertEnabled) {
                    NotificationHelper.showLowBatteryNotification(context, percentage)
                }
                if (currentSettings.isVibrationEnabled) {
                    NotificationHelper.triggerVibration(context)
                }
                scope.launch {
                    _alertEvent.emit("LOW_BATTERY_ALERT")
                }
            }
        } else if (percentage > currentSettings.lowBatteryThreshold + 5) {
            // Reset trigger when battery is charged back above 25%
            lowBatteryAlertFiredForCycle = false
        }

        // Check Charging Restriction Alert (>= 85% by default)
        if (isCharging && percentage >= currentSettings.chargingLimitThreshold) {
            if (!chargeLimitAlertFiredForCycle) {
                chargeLimitAlertFiredForCycle = true
                if (currentSettings.isSoundAlertEnabled) {
                    NotificationHelper.showChargingLimitNotification(context, percentage, currentSettings.chargingLimitThreshold)
                }
                if (currentSettings.isVibrationEnabled) {
                    NotificationHelper.triggerVibration(context)
                }
                scope.launch {
                    _alertEvent.emit("CHARGE_LIMIT_ALERT")
                }
            }
        }
    }

    private fun loadSettings(): GuardianSettings {
        return GuardianSettings(
            isGuardianServiceEnabled = prefs.getBoolean("service_enabled", true),
            lowBatteryThreshold = prefs.getInt("low_battery_threshold", 20),
            chargingLimitThreshold = prefs.getInt("charging_limit_threshold", 85),
            isSoundAlertEnabled = prefs.getBoolean("sound_alert_enabled", true),
            isVibrationEnabled = prefs.getBoolean("vibration_enabled", true),
            isAmoledScreenOnCharge = prefs.getBoolean("amoled_screen_charge", false)
        )
    }

    fun updateSettings(newSettings: GuardianSettings) {
        _settings.value = newSettings
        prefs.edit()
            .putBoolean("service_enabled", newSettings.isGuardianServiceEnabled)
            .putInt("low_battery_threshold", newSettings.lowBatteryThreshold)
            .putInt("charging_limit_threshold", newSettings.chargingLimitThreshold)
            .putBoolean("sound_alert_enabled", newSettings.isSoundAlertEnabled)
            .putBoolean("vibration_enabled", newSettings.isVibrationEnabled)
            .putBoolean("amoled_screen_charge", newSettings.isAmoledScreenOnCharge)
            .apply()
    }

    fun triggerTestAlert() {
        val current = _batteryState.value
        NotificationHelper.showLowBatteryNotification(context, current.percentage)
        NotificationHelper.triggerVibration(context)
        scope.launch {
            _alertEvent.emit("TEST_ALERT")
        }
    }
}
