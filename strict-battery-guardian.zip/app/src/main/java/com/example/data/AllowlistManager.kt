package com.example.data

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import java.util.Calendar

class AllowlistManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("strict_allowlist_prefs", Context.MODE_PRIVATE)

    companion object {
        const val PKG_WHATSAPP = "com.whatsapp"
        const val PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b"
        const val ID_PHONE = "core_phone"
        const val ID_SMS = "core_sms"
        const val ID_WHATSAPP = "core_whatsapp"
    }

    fun isAppInstalled(packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(packageName, 0)
            }
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun isWhatsAppInstalled(): Boolean {
        return isAppInstalled(PKG_WHATSAPP) || isAppInstalled(PKG_WHATSAPP_BUSINESS)
    }

    fun getWhatsAppPackage(): String {
        return if (isAppInstalled(PKG_WHATSAPP)) PKG_WHATSAPP else PKG_WHATSAPP_BUSINESS
    }

    fun launchPhone(): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun launchSms(): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun launchWhatsApp(): Boolean {
        return try {
            val pkg = getWhatsAppPackage()
            val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                true
            } else {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?text=")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    fun launchAppByPackage(packageName: String): Boolean {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun getCoreAllowedApps(): List<AllowedAppItem> {
        val usageMap = getTodayUsageMinutesMap()
        val isWhatsapp = isWhatsAppInstalled()
        val whatsappPkg = getWhatsAppPackage()

        return listOf(
            AllowedAppItem(
                id = ID_PHONE,
                packageName = "com.samsung.android.dialer",
                nameGujarati = "ફોન (Phone / Dialler)",
                nameEnglish = "Phone",
                isInstalled = true,
                isCoreApp = true,
                usageTimeMinutesToday = usageMap["com.samsung.android.dialer"] ?: usageMap["com.google.android.dialer"] ?: 0
            ),
            AllowedAppItem(
                id = ID_SMS,
                packageName = "com.samsung.android.messaging",
                nameGujarati = "સંદેશા (Messages / SMS)",
                nameEnglish = "Messages",
                isInstalled = true,
                isCoreApp = true,
                usageTimeMinutesToday = usageMap["com.samsung.android.messaging"] ?: usageMap["com.google.android.apps.messaging"] ?: 0
            ),
            AllowedAppItem(
                id = ID_WHATSAPP,
                packageName = whatsappPkg,
                nameGujarati = "વોટ્સએપ (WhatsApp)",
                nameEnglish = "WhatsApp",
                isInstalled = isWhatsapp,
                isCoreApp = true,
                usageTimeMinutesToday = usageMap[whatsappPkg] ?: 0
            )
        )
    }

    fun getCustomAllowedPackages(): Set<String> {
        return prefs.getStringSet("custom_allowed_pkgs", emptySet()) ?: emptySet()
    }

    fun addCustomAllowedPackage(pkg: String) {
        val current = getCustomAllowedPackages().toMutableSet()
        current.add(pkg)
        prefs.edit().putStringSet("custom_allowed_pkgs", current).apply()
    }

    fun removeCustomAllowedPackage(pkg: String) {
        val current = getCustomAllowedPackages().toMutableSet()
        current.remove(pkg)
        prefs.edit().putStringSet("custom_allowed_pkgs", current).apply()
    }

    fun getCustomAllowedApps(): List<AllowedAppItem> {
        val pkgs = getCustomAllowedPackages()
        val pm = context.packageManager
        val usageMap = getTodayUsageMinutesMap()

        return pkgs.mapNotNull { pkg ->
            try {
                val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getApplicationInfo(pkg, 0)
                }
                val label = pm.getApplicationLabel(appInfo).toString()
                AllowedAppItem(
                    id = pkg,
                    packageName = pkg,
                    nameGujarati = label,
                    nameEnglish = label,
                    isInstalled = true,
                    isCoreApp = false,
                    usageTimeMinutesToday = usageMap[pkg] ?: 0
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    fun getAllInstalledLaunchableApps(): List<AppItem> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
        }

        return resolveInfos.mapNotNull { info ->
            val pkg = info.activityInfo.packageName
            if (pkg == context.packageName) null
            else {
                val label = info.loadLabel(pm).toString()
                AppItem(packageName = pkg, label = label)
            }
        }.distinctBy { it.packageName }.sortedBy { it.label }
    }

    fun hasUsageStatsPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun getTodayUsageMinutesMap(): Map<String, Long> {
        if (!hasUsageStatsPermission()) return emptyMap()

        return try {
            val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return emptyMap()
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val startMillis = cal.timeInMillis
            val endMillis = System.currentTimeMillis()

            val statsList = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, startMillis, endMillis)
            val result = mutableMapOf<String, Long>()
            statsList?.forEach { stat ->
                val minutes = stat.totalTimeInForeground / (1000 * 60)
                if (minutes > 0) {
                    result[stat.packageName] = minutes
                }
            }
            result
        } catch (_: Exception) {
            emptyMap()
        }
    }
}
