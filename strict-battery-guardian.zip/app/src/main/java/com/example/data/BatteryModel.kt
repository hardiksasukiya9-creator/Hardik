package com.example.data

import android.graphics.drawable.Drawable

enum class BatteryStatus {
    CHARGING,
    DISCHARGING,
    FULL,
    NOT_CHARGING,
    UNKNOWN;

    fun getGujaratiLabel(): String = when (this) {
        CHARGING -> "ચાર્જ થઈ રહી છે"
        DISCHARGING -> "ડિસ્ચાર્જ (બેટરી વપરાશ)"
        FULL -> "બેટરી પૂર્ણ (૧૦૦%)"
        NOT_CHARGING -> "ચાર્જ નથી થઈ રહી"
        UNKNOWN -> "અજ્ઞાત સ્થિતિ"
    }
}

enum class PlugType {
    AC,
    USB,
    WIRELESS,
    BATTERY;

    fun getGujaratiLabel(): String = when (this) {
        AC -> "AC એડેપ્ટર (૧૫W ફાસ્ટ ચાર્જિંગ)"
        USB -> "USB કનેક્શન"
        WIRELESS -> "વાયરલેસ ચાર્જર"
        BATTERY -> "બેટરી પાવર પર"
    }
}

enum class BatteryHealth {
    GOOD,
    OVERHEAT,
    DEAD,
    OVER_VOLTAGE,
    COLD,
    UNKNOWN;

    fun getGujaratiLabel(): String = when (this) {
        GOOD -> "ઉત્તમ (Good)"
        OVERHEAT -> "અતિશય ગરમ (Overheat - સાવચેત રહો)"
        DEAD -> "ખરાબ (Dead)"
        OVER_VOLTAGE -> "હાઈ વોલ્ટેજ (Over Voltage)"
        COLD -> "ખૂબ ઠંડી (Cold)"
        UNKNOWN -> "સામાન્ય (Normal)"
    }
}

data class BatteryState(
    val percentage: Int = 50,
    val isCharging: Boolean = false,
    val status: BatteryStatus = BatteryStatus.DISCHARGING,
    val plugType: PlugType = PlugType.BATTERY,
    val health: BatteryHealth = BatteryHealth.GOOD,
    val temperatureCelsius: Float = 30.0f,
    val voltageVolts: Float = 3.85f,
    val technology: String = "Li-ion",
    val isPowerSaveMode: Boolean = false,
    val estimatedCapacityMah: Int = 2000,
    val chargingSpeedWatts: Float = 0.0f,
    val timestampMillis: Long = System.currentTimeMillis()
)

data class GuardianSettings(
    val isGuardianServiceEnabled: Boolean = true,
    val lowBatteryThreshold: Int = 20,
    val chargingLimitThreshold: Int = 85, // Samsung Galaxy Protect Battery standard
    val isSoundAlertEnabled: Boolean = true,
    val isVibrationEnabled: Boolean = true,
    val isAmoledScreenOnCharge: Boolean = false
)

data class AllowedAppItem(
    val id: String,
    val packageName: String,
    val nameGujarati: String,
    val nameEnglish: String,
    val isInstalled: Boolean,
    val isCoreApp: Boolean = true,
    val usageTimeMinutesToday: Long = 0
)

data class AppItem(
    val packageName: String,
    val label: String
)
