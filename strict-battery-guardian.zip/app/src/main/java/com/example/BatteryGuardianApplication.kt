package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class BatteryGuardianApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val alertChannel = NotificationChannel(
                CHANNEL_ALERTS_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.notif_channel_desc)
                enableVibration(true)
                enableLights(true)
            }

            val serviceChannel = NotificationChannel(
                CHANNEL_SERVICE_ID,
                "Strict Battery Guardian Monitoring Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "બેકગ્રાઉન્ડ બેટરી મોનિટરિંગ સર્વિસ"
                setShowBadge(false)
            }

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.let {
                it.createNotificationChannel(alertChannel)
                it.createNotificationChannel(serviceChannel)
            }
        }
    }

    companion object {
        const val CHANNEL_ALERTS_ID = "strict_battery_alerts"
        const val CHANNEL_SERVICE_ID = "strict_battery_service"
    }
}
