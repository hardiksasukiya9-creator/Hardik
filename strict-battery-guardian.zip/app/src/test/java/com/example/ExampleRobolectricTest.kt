package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.AllowedAppItem
import com.example.data.AllowlistManager
import com.example.data.BatteryHealth
import com.example.data.BatteryState
import com.example.data.BatteryStatus
import com.example.data.PlugType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Strict Battery Guardian", appName)
    }

    @Test
    fun testGujaratiAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appNameGujarati = context.getString(R.string.app_name_gujarati)
        assertEquals("સ્ટ્રિક્ટ બેટરી ગાર્ડિયન", appNameGujarati)
    }

    @Test
    fun testBatteryStatusGujaratiLabels() {
        assertEquals("ચાર્જ થઈ રહી છે", BatteryStatus.CHARGING.getGujaratiLabel())
        assertEquals("ડિસ્ચાર્જ (બેટરી વપરાશ)", BatteryStatus.DISCHARGING.getGujaratiLabel())
        assertEquals("બેટરી પૂર્ણ (૧૦૦%)", BatteryStatus.FULL.getGujaratiLabel())
    }

    @Test
    fun testPlugTypeGujaratiLabels() {
        assertTrue(PlugType.AC.getGujaratiLabel().contains("૧૫W"))
        assertTrue(PlugType.BATTERY.getGujaratiLabel().contains("બેટરી"))
    }

    @Test
    fun testBatteryHealthGujaratiLabels() {
        assertTrue(BatteryHealth.GOOD.getGujaratiLabel().contains("Good"))
        assertTrue(BatteryHealth.OVERHEAT.getGujaratiLabel().contains("Overheat"))
    }

    @Test
    fun testCoreAllowlistConfiguration() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val allowlistManager = AllowlistManager(context)
        val coreApps = allowlistManager.getCoreAllowedApps()

        assertEquals(3, coreApps.size)
        val ids = coreApps.map { it.id }
        assertTrue(ids.contains(AllowlistManager.ID_PHONE))
        assertTrue(ids.contains(AllowlistManager.ID_SMS))
        assertTrue(ids.contains(AllowlistManager.ID_WHATSAPP))
    }

    @Test
    fun testBatteryStateCapacityCalculation() {
        val state = BatteryState(
            percentage = 80,
            isCharging = true,
            estimatedCapacityMah = 3200
        )
        assertEquals(80, state.percentage)
        assertEquals(3200, state.estimatedCapacityMah)
        assertTrue(state.isCharging)
    }
}
